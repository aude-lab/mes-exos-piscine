package fr.epita.assistants.loggingbasics;

import ch.qos.logback.classic.Logger;

import java.util.*;

public class Trombinoscope {
    private final Logger LOGGER;
    private final HashMap<String, Long> map;

    public Trombinoscope() {
        // FIXME: Instantiate logger with level TRACE

        // FIXME: Add logging here

        map = new HashMap<>();
    }

    public Long putPerson(String name, long photoId) {
        // FIXME: Add logging here

        Long oldPhotoId = map.put(name,
                                  photoId);

        // FIXME: Add logging here

        return oldPhotoId;
    }
}
