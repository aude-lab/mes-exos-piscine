package fr.epita.assistants.yakamon.utils.tile;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public abstract class CollectibleInfo {

    private Character value;
}
