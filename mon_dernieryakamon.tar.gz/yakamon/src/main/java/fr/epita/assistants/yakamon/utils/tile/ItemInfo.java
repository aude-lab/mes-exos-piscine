package fr.epita.assistants.yakamon.utils.tile;

import lombok.Getter;

@Getter
public class ItemInfo extends CollectibleInfo {
    public ItemInfo(Character value) {
        super(value);
    }
}