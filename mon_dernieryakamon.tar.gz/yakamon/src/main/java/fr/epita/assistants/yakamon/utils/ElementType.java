package fr.epita.assistants.yakamon.utils;

public enum ElementType {
    BUG,
    DARK,
    ELECTRIC,
    FAIRY,
    FIGHTING,
    FIRE,
    FLYING,
    GHOST,
    GRASS,
    GROUND,
    ICE,
    NORMAL,
    POISON,
    PSYCHIC,
    ROCK,
    STEEL,
    WATER,
    DRAGON,
    STELLAR
}
