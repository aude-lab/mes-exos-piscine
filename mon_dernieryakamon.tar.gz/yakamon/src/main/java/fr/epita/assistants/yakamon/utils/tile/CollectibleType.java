package fr.epita.assistants.yakamon.utils.tile;

public enum CollectibleType {
    ITEM,
    YAKAMON;
}
